<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>read-artikelen.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Artikelen</h1>
<p>Hier kunt u alle artikelen vinden.</p>
<?php

require_once "../connect.php";

$artikelen = $conn->prepare("
                                    select              artId,
                                                        artOmschrijving, 
                                                        artInkoop, 
                                                        artVerkoop, 
                                                        artVoorraad,
                                                        artMinVoorraad,
                                                        artMaxVoorraad,
                                                        artLocatie,
                                                        LevId
                                    from                artikelen      ");

$artikelen->execute();
echo "<table>";
foreach($artikelen as $artikel)
{
    echo "<tr>";
    echo "<td>" . $artikel["artId"] . "</td>";
    echo "<td>" . $artikel["artOmschrijving"] . "</td>";
    echo "<td>" . $artikel["artInkoop"] . "</td>";
    echo "<td>" . $artikel["artVerkoop"] . "</td>";
    echo "<td>" . $artikel["artVoorraad"] . "</td>";
    echo "<td>" . $artikel["artMinVoorraad"] . "</td>";
    echo "<td>" . $artikel["artMaxVoorraad"] . "</td>";
    echo "<td>" . $artikel["artLocatie"] . "</td>";
    echo "<td>" . $artikel["LevId"] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo"<a href='levmenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
