<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>read-leverantie.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Read leverantie</h1>
<p>Alle leveranties.</p>
<?php

require_once "../connect.php";

$leveranties = $conn->prepare("
                                    select              LevId,
                                                        LevNaam, 
                                                        LevContact, 
                                                        LevEmail, 
                                                        LevAdres,
                                                        LevPostcode
                                    from                leverantie      ");

$leveranties->execute();
echo "<table>";
foreach($leveranties as $leverantie)
{
    echo "<tr>";
    echo "<td>" . $leverantie["LevId"] . "</td>";
    echo "<td>" . $leverantie["LevNaam"] . "</td>";
    echo "<td>" . $leverantie["LevContact"] . "</td>";
    echo "<td>" . $leverantie["LevEmail"] . "</td>";
    echo "<td>" . $leverantie["LevAdres"] . "</td>";
    echo "<td>" . $leverantie["LevPostcode"] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo"<a href='levmenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
