<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>create-artikelen2.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Create Artikel</h1>
<p>
    Hier kunt u een artikel toevoegen
</p>
<?php
$artId = NULL;
$artOmschrijving=$_POST["artOmschrijvingvak"];
$artInkoop=$_POST["artInkoopvak"];
$artVerkoop=$_POST["artVerkoopvak"];
$artVoorraad=$_POST["artVoorraadvak"];
$artMinVoorraad=$_POST["artMinVoorraadvak"];
$artMaxVoorraad=$_POST["artMaxVoorraadvak"];
$artLocatie=$_POST["artLocatievak"];
$LevId=$_POST["LevIdvak"];

require_once "../connect.php";


$sql = $conn->prepare("insert into artikelen values(:artId, :artOmschrijving, :artInkoop, :artVerkoop, :artVoorraad, :artMinVoorraad, :artMaxVoorraad, :artLocatie, :LevId)");

$sql->bindParam(":artId", $artId);
$sql->bindParam("artOmschrijving", $artOmschrijving);
$sql->bindParam("artInkoop", $artInkoop);
$sql->bindParam("artVerkoop", $artVerkoop);
$sql->bindParam("artVoorraad", $artVoorraad);
$sql->bindParam("artMinVoorraad", $artMinVoorraad);
$sql->bindParam("artMaxVoorraad", $artMaxVoorraad);
$sql->bindParam("artLocatie", $artLocatie);
$sql->bindParam("LevId", $LevId);

$sql->execute([
    "artId"                 => $artId,
    "artOmschrijving"       => $artOmschrijving,
    "artInkoop"             => $artInkoop,
    "artVerkoop"            => $artVerkoop,
    "artVoorraad"           => $artVoorraad,
    "artMinVoorraad"        => $artMinVoorraad,
    "artMaxVoorraad"        => $artMaxVoorraad,
    "artLocatie"            => $artLocatie,
    "LevId"                 => $LevId
]);

echo "Leverantie toegevoegd <br/>";
echo "<a href='levmenu.php'> terug naar het menu </a>"

?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
