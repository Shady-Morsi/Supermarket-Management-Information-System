<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>update-leverantie2.php</title>
    <link rel="stylesheet" href="mencss.css">
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>  Update Leverantier</h1>
<P>
    Dit formulier word gebruikt om leverantiers te weizigen
</P>
<?php
//artid uit het formulier halen
$levid =$_POST["levidvak"];
///SQL;
require_once "../connect.php";
//Artid mag niet gewijzigd worden
$leverantie= $conn->prepare("
    select levid,
           levnaam,
           levcontact,
           levemail,
           levadres,
           levpostcode
    from   leverantie
    where levid = :levid
    ");
$leverantie->execute(["levid"=>$levid]);
//nieuw formulier
echo "<form action='update-leverantie3.php' method='post'>";
foreach ($leverantie as $lev)
{
//artid mag niet gewijzigd worden
    echo "levid:" . $lev ["levid"];
    echo " <input type='hidden' name ='levidvak' ";
    echo " value=' ". $lev["levid"]. "'> <br/>";

    echo "levnaam: <input type='text' ";
    echo "name ='levnaamvak'";
    echo " value=' ".$lev["levnaam"]. "' ";
    echo "'> <br/>";

    echo "levcontact: <input type='text' ";
    echo "name ='levcontactvak'";
    echo " value=' ".$lev["levcontact"]. "' ";
    echo "'> <br/>";

    echo "levemail: <input type='text' ";
    echo "name ='levemailvak'";
    echo " value=' ".$lev["levemail"]. "' ";
    echo "'> <br/>";

    echo "levadres: <input type='text' ";
    echo "name ='levadresvak'";
    echo " value=' ".$lev["levadres"]. "' ";
    echo "'> <br/>";

    echo "levpostcode: <input type='text' ";
    echo "name ='levpostcodevak'";
    echo " value=' ".$lev["levpostcode"]. "' ";
    echo "'> <br/>";
}
echo "<input type='submit' name='submit' value='Submit' div= submit>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
