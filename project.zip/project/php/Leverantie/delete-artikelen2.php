<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>delete-artikelen2.php</title>
    <link rel="stylesheet" href="../mencss.css">

</head>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>  Verwijder</h1>
<P>
    Verwijder een artikel
</P>
<?php
//echo "<pre>".print_r($_POST, true)."</pre>";

//artikel uit het formulier
$artid = $_POST["artidvak"];
///de artikelgegevens uit de tabel halen
require_once "../connect.php";
//de artikelgegevens
$artikelen= $conn->prepare("
select artid,
       artomschrijving,
       artinkoop,
       artverkoop,
       artvoorraad,
       artminvoorraad,
       artmaxvoorraad,
       artlocatie,
       levid
 from  artikelen
where artid = :artid ");
$artikelen->execute(["artid"=>$artid]);
echo "<table>";
while ($row = $artikelen->fetch(PDO::FETCH_ASSOC))
{
    extract($row);

    echo "<tr>";
    echo  "<td>".$artid . "</td>";
    echo  "<td>".$artomschrijving . "</td>";
    echo  "<td>".$artinkoop. "</td>";
    echo  "<td>".$artverkoop . "</td>";
    echo  "<td>".$artvoorraad . "</td>";
    echo  "<td>".$artminvoorraad . "</td>";
    echo  "<td>".$artmaxvoorraad . "</td>";
    echo  "<td>".$artlocatie . "</td>";
    echo  "<td>".$levid. "</td>";
    echo "</tr>";
}
echo "</table><br/>";

echo "<form action='delete-artikelen3.php' method ='post'>";
//waarde null als dit niet gecheckt word
echo "<input type='hidden' name='artidvak' value='".$artid."'>";
echo "Verwijder deze artikel. <br/>";
echo "<input type='checkbox' name='verwijdervak' value='1'>";
echo "<input  type='submit' div class = submit>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
