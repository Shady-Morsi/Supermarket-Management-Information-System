<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>create-leverantie2.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Create leverantie 2</h1>
<p>
    Leverantie toevoegen
</p>
<?php
$LevId = NULL;
$LevNaam=$_POST["Levnaamvak"];
$LevContact=$_POST["Levcontactvak"];
$LevEmail=$_POST["Levemailvak"];
$LevAdres=$_POST["Levadresvak"];
$LevPostcode=$_POST["Levpostcodevak"];

require_once "../connect.php";


$sql = $conn->prepare("insert into leverantie values(:LevId, :LevNaam, :LevContact, :LevEmail, :LevAdres, :LevPostcode)");

$sql->bindParam(":LevId", $LevId);
$sql->bindParam("LevNaam", $LevNaam);
$sql->bindParam("LevContact", $LevContact);
$sql->bindParam("LevEmail", $LevEmail);
$sql->bindParam("LevAdres", $LevAdres);
$sql->bindParam("LevPostcode", $LevPostcode);

$sql->execute([
    "LevId"         => $LevId,
    "LevNaam"       => $LevNaam,
    "LevContact"    => $LevContact,
    "LevEmail"      => $LevEmail,
    "LevAdres"      => $LevAdres,
    "LevPostcode"   => $LevPostcode
]);

echo "Leverantie toegevoegd <br/>";
echo "<a href='levmenu.php'> terug naar het menu </a>"

?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
