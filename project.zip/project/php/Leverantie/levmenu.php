<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Adam en Shady">
    <title>Levmenu</title>
    <style>
        .button {
            font-family: "Roboto", sans-serif;
            text-transform: uppercase;
            outline: 0;
            background: #ce000c;
            width: 25%;
            border: 0;
            padding: 15px;
            color: #FFFFFF;
            font-size: 14px;
            -webkit-transition: all 0.3 ease;
            transition: all 0.3 ease;
            cursor: pointer;
        }
        .form button:hover,.form button:active,.form button:focus {
            background: #fc8474;
        }
        input {
            width: 25%;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #ce000c;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #EF3B3A;
        }
        li a:hover {
            background-color: #EF3B3A;
        }
        .Klantenmenu ,.Leveringmenu {
            display:inline-block;
        }
    </style>
</head>
<body>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Menu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
Welkom Gebruiker<br>
<div class = "Orders"></div>

<h2>Artikelenmenu</h2>
<div class  = "button"><a href="create-artikelen1.php">Create</a></div><br>
<div class  = "button"><a href="read-artikelen.php">Read</a></div><br>
<div class  = "button"><a href="update-artikelen1.php">Update</a></div><br>
<div class  = "button"><a href="delete-artikelen1.php">Delete</a></div><br>
<div class  = "button"><a href="search-artikelen1.php">Search</a></div><br>
<div class = "Orders"></div>
<h2>Leverantiemenu</h2>
<div class  = "button"><a href="create-leverantie1.php">Create</a></div><br>
<div class  = "button"><a href="read-leverantie.php">Read</a></div><br>
<div class  = "button"><a href="update-leverantie1.php">Update</a></div><br>
<div class  = "button"><a href="delete-leverantie1.php">Delete</a></div><br>
<div class  = "button"><a href="search-leverantie1.php">Search</a></div><br>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
