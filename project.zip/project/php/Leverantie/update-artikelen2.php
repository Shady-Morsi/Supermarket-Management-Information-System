<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>update-artikelen2.php</title>
    <link rel="stylesheet" href="mencss.css">
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="levmenu.php">Leverantiemenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>  Update Artikelen </h1>
<P>
    Dit formulier word gebruikt om artikelen te weizigen
</P>
<?php
//artid uit het formulier halen
$artid =$_POST["artidvak"];
///SQL;
require_once "../connect.php";
//Artid mag niet gewijzigd worden
$artikelen= $conn->prepare("
    select artid,
           artomschrijving,
           artinkoop,
           artverkoop,
           artvoorraad,
           artminvoorraad,
           artmaxvoorraad,
           artlocatie, 
           levid
    from   artikelen
    where artid = :artid
    ");
$artikelen->execute(["artid"=>$artid]);
//nieuw formulier
echo "<form action='update-artikelen3.php' method='post'>";
foreach ($artikelen as $artikel)
{
//artid mag niet gewijzigd worden
echo "artid:" . $artikel ["artid"];
echo " <input type='hidden' name ='artidvak' ";
echo " value=' ". $artikel["artid"]. "'> <br/>";

echo "artomscrijving: <input type='text' ";
echo "name ='artomschrijvingvak'";
echo " value=' ".$artikel["artomschrijving"]. "' ";
echo "'> <br/>";

echo "artinkoop: <input type='text' ";
echo "name ='artinkoopvak'";
echo " value=' ".$artikel["artinkoop"]. "' ";
echo "'> <br/>";

echo "artverkoop: <input type='text' ";
echo "name ='artverkoopvak'";
echo " value=' ".$artikel["artverkoop"]. "' ";
echo "'> <br/>";

echo "artvoorraad: <input type='text' ";
echo "name ='artvoorraadvak'";
echo " value=' ".$artikel["artvoorraad"]. "' ";
echo "'> <br/>";

echo "artminvoorraad: <input type='text' ";
echo "name ='artminvoorraadvak'";
echo " value=' ".$artikel["artminvoorraad"]. "' ";
echo "'> <br/>";

echo "artmaxvoorraad: <input type='text' ";
echo "name ='artmaxvoorraadvak'";
echo " value=' ".$artikel["artmaxvoorraad"]. "' ";
echo "'> <br/>";

echo "artlocatie: <input type='text' ";
echo "name ='artlocatievak'";
echo " value=' ".$artikel["artlocatie"]. "' ";
echo "'> <br/>";

echo "levid: <input type='text' ";
echo "name ='levidvak'";
echo " value=' ".$artikel["levid"]. "' ";
echo "'> <br/>";

}
echo "<input  = submit type='submit' name='submit' value='Submit' div class = submit>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
