<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../mencss.css">
    <title>update-klant3.php</title>
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="klantmenu.php">Klantmenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1> Klant update </h1>
<P> Dit formulier is om klantengegevens te wijzigen</P>
<?php
$klantid = $_POST ["klantidvak"];
$klantnaam = $_POST ["klantnaamvak"];
$klantemail = $_POST ["klantemailvak"];
$klantadres= $_POST ["klantadresvak"];
$klantpostcode = $_POST ["klantpostcodevak"];
$klantwoonplaats = $_POST ["klantwoonplaatsvak"];
require_once "../connect.php";
$sql = $conn->prepare("
update klanten set klantid = :klantid,
                 klantnaam = :klantnaam,
                 klantemail = :klantemail,
                 klantadres = :klantadres,
                 klantpostcode = :klantpostcode,
                 klantwoonplaats= :klantwoonplaats
         where   klantid = :klantid 
");
$sql->execute([
    "klantid" => $klantid,
	"klantnaam" => $klantnaam,
    "klantemail" => $klantemail,
    "klantadres" => $klantadres,
    "klantpostcode" => $klantpostcode,
    "klantwoonplaats" => $klantwoonplaats,
]);
echo "De klant is gewijzigd. <br/>";
echo "<a href='klantmenu.php'>Terug naar het menu. <a/>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html> 
