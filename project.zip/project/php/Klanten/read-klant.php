<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>read-klant.php</title>
    <link rel="stylesheet" href="../mencss.css">
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">

    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="klantmenu.php">Klantmenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Alle klanten</h1>
<?php

require_once "../connect.php";

$klanten = $conn->prepare("
                                    select              Klantid,
                                                        Klantnaam, 
                                                        Klantemail, 
                                                        Klantadres, 
                                                        Klantpostcode,
                                                        Klantwoonplaats
                                    from                klanten      ");

$klanten->execute();
echo "<table>";
foreach($klanten as $klant)
{
    echo "<tr>";
    echo "<td>" . $klant["Klantid"] . "</td>";
    echo "<td>" . $klant["Klantnaam"] . "</td>";
    echo "<td>" . $klant["Klantemail"] . "</td>";
    echo "<td>" . $klant["Klantadres"] . "</td>";
    echo "<td>" . $klant["Klantwoonplaats"] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo"<a href='klantmenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>

