<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>create-klant2.php</title>
        <link rel="stylesheet" href="../mencss.css">
</head>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="klantmenu.php">Klantmenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>>
    </ul>
</header>
<body>
<h1>Voeg een klant toe</h1>
<?php
$Klantid = NULL;
$Klantnaam=$_POST["klantnaamvak"];
$Klantemail=$_POST["klantemailvak"];
$Klantadres=$_POST["klantadresvak"];
$Klantpostcode=$_POST["klantpostcodevak"];
$Klantwoonplaats=$_POST["klantwoonplaatsvak"];

require_once "../connect.php";


$sql = $conn->prepare("insert into klanten values(:Klantid, :Klantnaam, :Klantemail, :Klantadres, :Klantpostcode, :Klantwoonplaats)");

$sql->bindParam(":Klantid", $Klantid);
$sql->bindParam("Klantnaam", $Klantnaam);
$sql->bindParam("Klantemail", $Klantemail);
$sql->bindParam("Klantadres", $Klantadres);
$sql->bindParam("Klantpostcode", $Klantpostcode);
$sql->bindParam("Klantwoonplaats", $Klantwoonplaats);

$sql->execute([
    "Klantid"         => $Klantid,
    "Klantnaam"       => $Klantnaam,
    "Klantemail"      => $Klantemail,
    "Klantadres"      => $Klantadres,
    "Klantpostcode"   => $Klantpostcode,
    "Klantwoonplaats" => $Klantwoonplaats
]);

echo "De klant is toegevoegd <br/>";
echo "<a href='klantmenu.php'> terug naar het menu </a>"

?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
