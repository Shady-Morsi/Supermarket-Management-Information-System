<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../mencss.css">
    <title>create-verkooporders2.php</title>

</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Create Verkooporders</h1>
<p>
    Hier kunt u verkooporders toevoegen
</p>
<?php
$VerkOrdId = NULL;
$Klantid=$_POST["Klantidvak"];
$artId=$_POST["artIdvak"];
$verkOrdDate= "2021-12-10";
$verkOrdBestAantal=$_POST["verkOrdBestAantalvak"];
$verkOrdStatus=$_POST["verkOrdStatus"];

require_once "../connect.php";

$sql = $conn->prepare("insert into verkooporders values(:verkOrdId, :Klantid, :artId, :verkOrdDate, :verkOrdBestAantal, :verkOrdStatus)");

$sql->bindParam(":verkOrdId", $verkOrdId);
$sql->bindParam("Klantid", $Klantid);
$sql->bindParam("artId", $artId);
$sql->bindParam("verkOrdDate", $verkOrdDate);
$sql->bindParam("verkOrdBestAantal", $verkOrdBestAantal);
$sql->bindParam("verkOrdStatus", $verkOrdStatus);

$sql->execute([
    "verkOrdId"                  => $verkOrdId,
    "Klantid"                    => $Klantid,
    "artId"                      => $artId,
    "verkOrdDate"                => $verkOrdDate,
    "verkOrdBestAantal"          => $verkOrdBestAantal,
    "verkOrdStatus"              => $verkOrdStatus,

]);

echo "Verkooporder toegevoegd <br/>";
echo "<a href='ordermenu.php'> terug naar het menu </a>"

?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
