<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../mencss.css">
    <title>update-inkooporders3.php</title>
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Wijzig Inkooporders</h1>
<?php
$inkordid = $_POST ["inkordidvak"];
$levid = $_POST ["levidvak"];
$artid = $_POST ["artidvak"];
$inkorddatum= $_POST ["inkorddatumvak"];
$inkordbestaantal = $_POST ["inkordbestaantalvak"];
$inkordstatus = $_POST ["inkordstatusvak"];
require_once "../connect.php";
$sql = $conn->prepare(
"UPDATE inkooporders
SET inkOrdBestAantal = :ninkordbestaantal,
    inkOrdStatus     = :ninkordstatus
WHERE inkordId       = :inkordid");
$sql->execute(
["ninkordbestaantal" => $inkordbestaantal,
"ninkordstatus" => $inkordstatus,
"inkordid" => $inkordid]
);
echo "De inkooporder is gewijzigd. <br/>";
echo "<a href='ordermenu.php'>Terug naar het menu. <a/>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
