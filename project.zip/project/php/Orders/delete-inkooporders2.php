<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>delete-inkooporders2.php</title>
    <link rel="stylesheet" href="../mencss.css">

</head>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>  delete 2</h1>
<P>
    Verwijder een inkooporder
</P>
<?php
//echo "<pre>".print_r($_POST, true)."</pre>";

//artikel uit het formulier
$inkordid= $_POST["inkordidvak"];
///de artikelgegevens uit de tabel halen
require_once "../connect.php";
//de artikelgegevens
$inkooporders= $conn->prepare("
select inkordid,
       levid,
       artid,
       inkorddatum,
       inkordbestaantal,
       inkordstatus
 from  inkooporders
where inkordid = :inkordid ");
$inkooporders->execute(["inkordid"=>$inkordid]);
echo "<table>";
while ($row = $inkooporders->fetch(PDO::FETCH_ASSOC))
{
    extract($row);

    echo "<tr>";
    echo  "<td>".$inkordid. "</td>";
    echo  "<td>".$levid. "</td>";
    echo  "<td>".$artid. "</td>";
    echo  "<td>".$inkorddatum . "</td>";
    echo  "<td>".$inkordbestaantal . "</td>";
    echo  "<td>".$inkordstatus . "</td>";
    echo "</tr>";
}
echo "</table><br/>";

echo "<form action='delete-inkooporders3.php' method ='post'>";
//waarde null als dit niet gecheckt word
echo "<input type='hidden' name='inkordidvak' value='".$inkordid."'>";
echo "Verwijder deze inkooporder. <br/>";
echo "<input type='checkbox' name='verwijdervak' value='1'>";
echo "<input div class = submit type='submit'>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
