<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>update-klant2.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Zoek Inkooporders</h1>
<?php
$inkOrdId = $_POST["inkOrdIdvak"] || "";
$LevId = $_POST["Levidvak"];
require_once "../connect.php";

$inkooporders = $conn->prepare("
                                   select     inkOrdId,
                                              LevId, 
                                              artId, 
                                              inkOrdDatum, 
                                              inkOrdBestAantal,
                                              inkOrdStatus
                                   from       inkooporders
                                   where      inkOrdId = :inkOrdId or :LevId = :LevId
                                   ");
$inkooporders->execute(["inkOrdId" =>$inkOrdId, "LevId" =>$LevId]);

echo "<table>";
foreach($inkooporders as $inkooporder)
{
    echo "<tr>";
    echo "<td>" . $inkooporder["inkOrdId"] . "</td>";
    echo "<td>" . $inkooporder["LevId"] . "</td>";
    echo "<td>" . $inkooporder["artId"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdDatum"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdBestAantal"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdStatus"] . "</td>";

    echo "</tr>";
}
echo "</table><br/>";
echo "<a href='ordermenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
