<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Shady en Adam"
    <meta charset="UTF-8">
    <link rel="stylesheet" href="mencss.css">
    <title>search-inkooporders2.php</title>
</head>
<body>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Read artikelen</h1>
<p>Hier kunt u alle inkooporders vinden.</p>
<?php

require_once "../connect.php";

$inkooporders = $conn->prepare("
                                    select              inkOrdId,
                                                        LevId, 
                                                        artId, 
                                                        inkOrdDatum, 
                                                        inkOrdBestAantal,
                                                        inkOrdStatus
                                                        
                                    from                inkooporders      ");

$inkooporders->execute();
echo "<table>";
foreach($inkooporders as $inkooporder)
{
    echo "<tr>";
    echo "<td>" . $inkooporder["inkOrdId"] . "</td>";
    echo "<td>" . $inkooporder["LevId"] . "</td>";
    echo "<td>" . $inkooporder["artId"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdDatum"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdBestAantal"] . "</td>";
    echo "<td>" . $inkooporder["inkOrdStatus"] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo"<a href='ordermenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
