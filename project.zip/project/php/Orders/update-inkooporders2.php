<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>update-inkooporders2.php</title>
    <link rel="stylesheet" href="mencss.css">
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>  Wijzig Inkooporders</h1>
<?php
//artid uit het formulier halen
$inkordid =$_POST["inkordidvak"];
///SQL;
require_once "../connect.php";
//Artid mag niet gewijzigd worden
$inkooporders= $conn->prepare("
    select inkordid,
           levid, 
           artid, 
           inkorddatum, 
           inkordbestaantal,
           inkordstatus
    from   inkooporders
    where inkordid = :inkordid
    ");
$inkooporders->execute(["inkordid"=>$inkordid]);
//nieuw formulier
echo "<form action='update-inkooporders3.php' method='post'>";
foreach ($inkooporders as $inkoop)
{
//artid mag niet gewijzigd worden
    echo "inkordid:" . $inkoop ["inkordid"];
    echo " <input type='hidden' name ='inkordidvak' ";
    echo " value=' ". $inkoop["inkordid"]. "'> <br/>";

    echo "levid: <input type='text' ";
    echo "name ='levidvak'";
    echo " value=' ".$inkoop["levid"]. "' ";
    echo "'> <br/>";

    echo "artid: <input type='text' ";
    echo "name ='artidvak'";
    echo " value=' ".$inkoop["artid"]. "' ";
    echo "'> <br/>";

    echo "inkorddatum: <input type='text' ";
    echo "name ='inkorddatumvak'";
    echo " value=' ".$inkoop["inkorddatum"]. "' ";
    echo "'> <br/>";

    echo "inkordbestaantal: <input type='text' ";
    echo "name ='inkordbestaantalvak'";
    echo " value=' ".$inkoop["inkordbestaantal"]. "' ";
    echo "'> <br/>";

    echo "inkordstatus: <input type='text' ";
    echo "name ='inkordstatusvak'";
    echo " value=' ".$inkoop["inkordstatus"]. "' ";
    echo "'> <br/>";
}
echo "<input  div class = submit type='submit' name='submit' value='Submit'>";
echo "</form>";
?>
<footer>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
