<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Shady en Adam"
    <meta charset="UTF-8">
    <link rel="stylesheet" href="mencss.css">
    <title>delete-verkooporders3.php</title>
</head>
<body>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>  delete 3</h1>
<p>
    Verwijder een verkooporder
</p>
<?php
$verkordid= $_POST["verkoridvak"];
$verwijder = $_POST ["verwijdervak"];

if ($verwijder)
{
    require_once "../connect.php";
    $sql = $conn->prepare("delete from verkooporders 
where verkordid = :verkordid");

    $sql->execute(["verkordid" =>$verkordid]);
    echo "De gegevens zijn verwijderd. <br/>";
    echo "<a href='ordermenu.php'>Terug naar het menu. <a/>";

}
else
{
    echo "De gegevens zijn niet verwijderd. <br/>";
    echo "<a href='ordermenu.php'>Terug naar het menu. <a/>";
}
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
