<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>delete-verkooporders2.php</title>
    <link rel="stylesheet" href="../mencss.css">

</head>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>  delete 2</h1>
<P>
    Verwijder een verkooporder
</P>
<?php
//echo "<pre>".print_r($_POST, true)."</pre>";

//artikel uit het formulier
$verkordid= $_POST["verkordidvak"];
///de artikelgegevens uit de tabel halen
require_once "../connect.php";
//de artikelgegevens
$verkooporders= $conn->prepare("
select verkordid,
       klantid,
       artid,
       verkorddate,
       verkordbestaantal,
       verkordstatus
 from  verkooporders
where verkordid = :verkordid ");
$verkooporders->execute(["verkordid"=>$verkordid]);
echo "<table>";
while ($row = $verkooporders->fetch(PDO::FETCH_ASSOC))
{
    extract($row);

    echo "<tr>";
    echo  "<td>".$verkordid. "</td>";
    echo  "<td>".$klantid. "</td>";
    echo  "<td>".$artid. "</td>";
    echo  "<td>".$verkorddate . "</td>";
    echo  "<td>".$verkordbestaantal . "</td>";
    echo  "<td>".$verkordstatus . "</td>";
    echo "</tr>";
}
echo "</table><br/>";

echo "<form action='delete-verkooporders3.php' method ='post'>";
//waarde null als dit niet gecheckt word
echo "<input type='hidden' name='verkoridvak' value='".$verkordid."'>";
echo "Verwijder deze verkooporder. <br/>";
echo "<input type='checkbox' name='verwijdervak' value='1'>";
echo "<input type='submit'>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
