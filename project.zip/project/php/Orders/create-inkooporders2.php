<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../mencss.css">
    <title>create-inkooporders2.php</title>
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1>Create Inkooporder</h1>
<p>
    Hier kunt u inkooporders toevoegen
</p>
<?php
$inkOrdId = NULL;
$LevId=$_POST["LevIdvak"];
$artId=$_POST["artIdvak"];
$inkOrdDatum= "2021-12-10";
$inkOrdBestAantal=$_POST["inkOrdBestAantalvak"];
$inkOrdStatus=$_POST["inkOrdStatus"];

require_once "../connect.php";


$sql = $conn->prepare("insert into inkooporders values(:inkOrdId, :LevId, :artId, :inkOrdDatum, :inkOrdBestAantal, :inkOrdStatus)");

$sql->bindParam(":inkOrdId", $inkOrdId);
$sql->bindParam("LevId", $LevId);
$sql->bindParam("artId", $artId);
$sql->bindParam("inkOrdDatum", $inkOrdDatum);
$sql->bindParam("inkOrdBestAantal", $inkOrdBestAantal);
$sql->bindParam("inkOrdStatus", $inkOrdStatus);

$sql->execute([
    "inkOrdId"                 => $inkOrdId,
    "LevId"                    => $LevId,
    "artId"                    => $artId,
    "inkOrdDatum"              => $inkOrdDatum,
    "inkOrdBestAantal"         => $inkOrdBestAantal,
    "inkOrdStatus"             => $inkOrdStatus,

]);

echo "Leverantie toegevoegd <br/>";
echo "<a href='ordermenu.php'> terug naar het menu </a>"

?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
