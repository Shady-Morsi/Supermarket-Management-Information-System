<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../mencss.css">
    <title>update-verkooporders3.php</title>
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1> Wijzig Verkooporders</h1>
<?php
$verkordid= $_POST ["verkordidvak"];
$klantid = $_POST ["klantidvak"];
$artid = $_POST ["artidvak"];
$verkorddate= $_POST ["verkorddatevak"];
$verkordbestaantal = $_POST ["verkordbestaantalvak"];
$verkordstatus = $_POST ["verkordstatusvak"];
require_once "../connect.php";
$sql = $conn->prepare(
    "UPDATE verkooporders
SET verkOrdBestAantal = :nverkordbestaantal,
    verkOrdStatus     = :nverkordstatus
WHERE verkOrdId       = :verkordid");
$sql->execute(
    ["nverkordbestaantal" => $verkordbestaantal,
    "nverkordstatus" => $verkordstatus,
    "verkordid" => $verkordid]
);
echo "De Verkoporder is gewijzigd. <br/>";
echo "<a href='ordermenu.php'>Terug naar het menu. <a/>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
