<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>update-inkooporders2.php</title>
    <link rel="stylesheet" href="mencss.css">
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<body>
<header>
    <img src="../tas.jpg" alt="Tas logo">
    <img src="../Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<h1> Wijzig Verkooporders</h1>
<?php
//artid uit het formulier halen
$verkordid =$_POST["verkordidvak"];
///SQL;
require_once "../connect.php";
//Artid mag niet gewijzigd worden
$verkooporders= $conn->prepare("
    select verkordid,
       klantid,
       artid,
       verkorddate,
       verkordbestaantal,
       verkordstatus
    from   verkooporders
    where verkordid = :verkordid
    ");
$verkooporders->execute(["verkordid"=>$verkordid]);
//nieuw formulier
echo "<form action='update-verkooporders3.php' method='post'>";
foreach ($verkooporders as $verkoop)
{
//artid mag niet gewijzigd worden
    echo "verkordid:" . $verkoop ["verkordid"];
    echo " <input type='hidden' name ='verkordidvak' ";
    echo " value=' ". $verkoop["verkordid"]. "'> <br/>";

    echo "klantid: <input type='text' ";
    echo "name ='klantidvak'";
    echo " value=' ".$verkoop["klantid"]. "' ";
    echo "'> <br/>";

    echo "artid: <input type='text' ";
    echo "name ='artidvak'";
    echo " value=' ".$verkoop["artid"]. "' ";
    echo "'> <br/>";

    echo "verkorddate: <input type='text' ";
    echo "name ='verkorddatevak'";
    echo " value=' ".$verkoop["verkorddate"]. "' ";
    echo "'> <br/>";

    echo "verkordbestaantal: <input type='text' ";
    echo "name ='verkordbestaantalvak'";
    echo " value=' ".$verkoop["verkordbestaantal"]. "' ";
    echo "'> <br/>";

    echo "verkordstatus: <input type='text' ";
    echo "name ='verkordstatusvak'";
    echo " value=' ".$verkoop["verkordstatus"]. "' ";
    echo "'> <br/>";
}
echo "<input  div class = submit type='submit' name='submit' value='Submit'>";
echo "</form>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
