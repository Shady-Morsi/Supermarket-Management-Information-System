<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>search-verkooporders1.php</title>
    <link rel="stylesheet" href="mencss.css">
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Zoek een Verkooporder</h1>
<?php
$verkOrdId = $_POST["VerKoopId"] || "";
$Klantid = $_POST["Klantidvak"];
require_once "../connect.php";

$verkooporders = $conn->prepare("
                                   select     verkOrdId,
                                              Klantid, 
                                              artId, 
                                              verkOrdDate, 
                                              verkOrdBestAantal,
                                              verkOrdStatus
                                   from       verkooporders
                                   where      verkOrdId = :verkOrdId or :Klantid = :Klantid
                                   ");
$verkooporders->execute(["verkOrdId" =>$verkOrdId, "Klantid" =>$Klantid]);

echo "<table>";
foreach($verkooporders as $verkooporder)
{
    echo "<tr>";
    echo "<td>" . $verkooporder["verkOrdId"] . "</td>";
    echo "<td>" . $verkooporder["Klantid"] . "</td>";
    echo "<td>" . $verkooporder["artId"] . "</td>";
    echo "<td>" . $verkooporder["verkOrdDate"] . "</td>";
    echo "<td>" . $verkooporder["verkOrdBestAantal"] . "</td>";
    echo "<td>" . $verkooporder["verkOrdStatus"] . "</td>";

    echo "</tr>";
}
echo "</table><br/>";
echo "<a href='ordermenu.php'> terug naar het menu </a>";
?>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
