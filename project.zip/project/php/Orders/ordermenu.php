<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Adam en Shady">
    <title>Ordermenu</title>
    <style>
        .button {
            font-family: "Roboto", sans-serif;
            text-transform: uppercase;
            outline: 0;
            background: #ce000c;
            width: 25%;
            border: 0;
            padding: 15px;
            color: #FFFFFF;
            font-size: 14px;
            -webkit-transition: all 0.3 ease;
            transition: all 0.3 ease;
            cursor: pointer;
        }
        .form button:hover,.form button:active,.form button:focus {
            background: #fc8474;
        }
        input {
            width: 25%;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #ce000c;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #EF3B3A;
        }
        li a:hover {
            background-color: #EF3B3A;
        }
        .Klantenmenu ,.Leveringmenu {
            display:inline-block;
        }
    </style>
</head>
<body>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Menu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
Welkom Gebruiker<br>
<div class = "Orders"></div>
<h2>Inkooporders</h2>
<div class  = "button"><a href="create-inkooporders1.php">Create</a></div><br>
<div class  = "button"><a href="read-inkooporders.php">Read</a></div><br>
<div class  = "button"><a href="update-inkooporders1.php">Update</a></div><br>
<div class  = "button"><a href="delete-inkooporders1.php">Delete</a></div><br>
<div class  = "button"><a href="search-inkooporders1.php">Search</a></div><br>
<div class = "Orders"></div>
<h2>Verkooporders</h2>
<div class  = "button"><a href="create-verkooporders1.php">Create</a></div><br>
<div class  = "button"><a href="read-verkooporders.php">Read</a></div><br>
<div class  = "button"><a href="update-verkooporders1.php">Update</a></div><br>
<div class  = "button"><a href="delete-verkooporders1.php">Delete</a></div><br>
<div class  = "button"><a href="search-verkooporders1.php">Search</a></div><br>
</body>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +31883134620 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</html>
