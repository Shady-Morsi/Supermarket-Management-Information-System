<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Adam en Shady">
    <meta charset="UTF-8">
    <title>search-verkooporders1.php</title>
    <link rel="stylesheet" href="mencss.css">
    <style>
        input[type=text], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type=submit] {
            width: 100%;
            background-color: #ce000c;
            color: snow;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #ff4d55;
        }
        div {
            border-radius: 5px;
            background-color: #cccccc;
            padding: 20px;
        }
    </style>
</head>
<header>
    <img src="tas.jpg" alt="Tas logo">
    <img src="Basfn.png" alt="Bas logo">
    <ul>
        <li><a href="../mainmenu.php">Hoofdmenu</a></li>
        <li><a href="ordermenu.php">Ordermenu</a></li>
        <li><a href="../../index.php">Log Uit</a></li>
    </ul>
</header>
<body>
<h1>Zoek Verkooporders</h1>
<form action="search-verkooporders2.php" method="post">
    Hier kunt u een Verkooporders vinden op id?
    <label>
        <input type="text" name="VerKoopId">
    </label><br/>
    <!--    <input div class="button" type="submit">-->
    <!--</form>-->
    <!--<form action="search-leverantie2.php" method="post">-->
    Of zoek op klantennummer   <label>
        <input type="text" name="Klantidvak">
    </label><br/>
    <input div class="button" type="submit">
</form>
<footer>
    <h1>Contactgegevens</h1>
    Bas van der Heijden <br>  Zevenkampse Ring 869  <br>  3069 MD Rotterdam. <br> +08001111216 <small>  (gratis nummer dat alleen vanuit Nederland gebeld kan worden)</small> </br>
</footer>
</body>
</html>
