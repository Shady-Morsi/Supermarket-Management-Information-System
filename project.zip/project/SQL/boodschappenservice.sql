-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 15 jan 2022 om 20:49
-- Serverversie: 10.4.16-MariaDB
-- PHP-versie: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boodschappenservice`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `artikelen`
--

CREATE TABLE `artikelen` (
  `artId` int(11) NOT NULL,
  `artOmschrijving` varchar(12) NOT NULL,
  `artInkoop` decimal(3,2) NOT NULL,
  `artVerkoop` decimal(3,2) NOT NULL,
  `artVoorraad` int(11) NOT NULL,
  `artMinVoorraad` int(11) NOT NULL,
  `artMaxVoorraad` int(11) NOT NULL,
  `artLocatie` int(11) NOT NULL,
  `LevId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `artikelen`
--

INSERT INTO `artikelen` (`artId`, `artOmschrijving`, `artInkoop`, `artVerkoop`, `artVoorraad`, `artMinVoorraad`, `artMaxVoorraad`, `artLocatie`, `LevId`) VALUES
(1, 'test', '1.00', '1.00', 4, 2, 5, 0, 1),
(2, 'text', '2.00', '3.00', 2, 2, 5, 0, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `inkooporders`
--

CREATE TABLE `inkooporders` (
  `inkOrdId` int(11) NOT NULL,
  `LevId` int(11) NOT NULL,
  `artId` int(11) NOT NULL,
  `inkOrdDatum` date NOT NULL DEFAULT current_timestamp(),
  `inkOrdBestAantal` int(11) NOT NULL,
  `inkOrdStatus` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `inkooporders`
--

INSERT INTO `inkooporders` (`inkOrdId`, `LevId`, `artId`, `inkOrdDatum`, `inkOrdBestAantal`, `inkOrdStatus`) VALUES
(1, 1, 1, '2021-12-10', 4, 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klanten`
--

CREATE TABLE `klanten` (
  `Klantid` int(11) NOT NULL,
  `Klantnaam` varchar(20) NOT NULL DEFAULT 'voor-en achternaam',
  `Klantemail` varchar(30) NOT NULL DEFAULT 'email klant',
  `Klantadres` varchar(30) NOT NULL DEFAULT 'Straat en huisnummer',
  `Klantpostcode` varchar(6) NOT NULL,
  `Klantwoonplaats` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `klanten`
--

INSERT INTO `klanten` (`Klantid`, `Klantnaam`, `Klantemail`, `Klantadres`, `Klantpostcode`, `Klantwoonplaats`) VALUES
(3, 'Voorbeeld', 'a@a.a', 'Test 28a', '1234AB', 'Willekeurigstraat 12A'),
(4, 'test', 'f@f.f', 'Test 25b', '5678XY', 'Willekeurigstraat 12A'),
(5, 'Adam', 'f@f.f', 'Test 28a', '1235FG', 'Willekeurigstraat 17F');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leverantie`
--

CREATE TABLE `leverantie` (
  `LevId` int(11) NOT NULL,
  `LevNaam` varchar(15) NOT NULL DEFAULT 'Bedrijfsnaam',
  `LevContact` varchar(20) NOT NULL DEFAULT 'contactpersoonnaam',
  `LevEmail` varchar(30) NOT NULL DEFAULT 'contactemail',
  `LevAdres` varchar(30) NOT NULL DEFAULT 'adres contactpersoon',
  `LevPostcode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `leverantie`
--

INSERT INTO `leverantie` (`LevId`, `LevNaam`, `LevContact`, `LevEmail`, `LevAdres`, `LevPostcode`) VALUES
(1, 'test', '0034123456', 'e@e.e', 'Test 12', '1234 X');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `rol`) VALUES
(1, 'Adam', 'AdamBenabou', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `verkooporders`
--

CREATE TABLE `verkooporders` (
  `verkOrdId` int(11) NOT NULL,
  `Klantid` int(11) NOT NULL,
  `artId` int(11) NOT NULL,
  `verkOrdDate` date NOT NULL DEFAULT current_timestamp(),
  `verkOrdBestAantal` int(11) NOT NULL,
  `verkOrdStatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `verkooporders`
--

INSERT INTO `verkooporders` (`verkOrdId`, `Klantid`, `artId`, `verkOrdDate`, `verkOrdBestAantal`, `verkOrdStatus`) VALUES
(2, 3, 1, '2021-12-10', 3, 1),
(4, 4, 2, '2021-12-10', 3, 1);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `artikelen`
--
ALTER TABLE `artikelen`
  ADD PRIMARY KEY (`artId`),
  ADD KEY `LevId` (`LevId`);

--
-- Indexen voor tabel `inkooporders`
--
ALTER TABLE `inkooporders`
  ADD PRIMARY KEY (`inkOrdId`),
  ADD UNIQUE KEY `LevId` (`LevId`),
  ADD KEY `artId` (`artId`);

--
-- Indexen voor tabel `klanten`
--
ALTER TABLE `klanten`
  ADD PRIMARY KEY (`Klantid`);

--
-- Indexen voor tabel `leverantie`
--
ALTER TABLE `leverantie`
  ADD PRIMARY KEY (`LevId`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `usernameunique` (`username`);

--
-- Indexen voor tabel `verkooporders`
--
ALTER TABLE `verkooporders`
  ADD PRIMARY KEY (`verkOrdId`),
  ADD KEY `Klantid` (`Klantid`),
  ADD KEY `artId` (`artId`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `artikelen`
--
ALTER TABLE `artikelen`
  MODIFY `artId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `inkooporders`
--
ALTER TABLE `inkooporders`
  MODIFY `inkOrdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `klanten`
--
ALTER TABLE `klanten`
  MODIFY `Klantid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `leverantie`
--
ALTER TABLE `leverantie`
  MODIFY `LevId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `verkooporders`
--
ALTER TABLE `verkooporders`
  MODIFY `verkOrdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `artikelen`
--
ALTER TABLE `artikelen`
  ADD CONSTRAINT `artikelen_ibfk_1` FOREIGN KEY (`LevId`) REFERENCES `leverantie` (`LevId`);

--
-- Beperkingen voor tabel `inkooporders`
--
ALTER TABLE `inkooporders`
  ADD CONSTRAINT `inkooporders_ibfk_1` FOREIGN KEY (`LevId`) REFERENCES `leverantie` (`LevId`),
  ADD CONSTRAINT `inkooporders_ibfk_2` FOREIGN KEY (`artId`) REFERENCES `artikelen` (`artId`);

--
-- Beperkingen voor tabel `verkooporders`
--
ALTER TABLE `verkooporders`
  ADD CONSTRAINT `verkooporders_ibfk_1` FOREIGN KEY (`Klantid`) REFERENCES `klanten` (`Klantid`),
  ADD CONSTRAINT `verkooporders_ibfk_2` FOREIGN KEY (`artId`) REFERENCES `artikelen` (`artId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
